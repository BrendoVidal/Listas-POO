/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.classes.fatec;

import br.com.telas.fatec.Clientes;
import java.awt.Component;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JRootPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Cliente MMS
 */
public class Tabelas {

    public void PreencherTabelaCliente(JTable tabela, Component rootPane) {
        try {
            Cliente c = new Cliente();
            DefaultTableModel dtmCliente = (DefaultTableModel) tabela.getModel();
            dtmCliente.setNumRows(0);
            int i;
            c.lerArquivoCliente();
            c.lerArquivoAnimal();
            for (i = 0; i < c.getIndex(); i = i + 4) {
                Object[] dados = {c.getClientelist(i), c.getClientelist(i + 1), c.getClientelist(i + 2), c.getClientelist(i + 3)};
                dtmCliente.addRow(dados);

            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Tabelas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void PreencherAnimal(JTable tabela, Component rootPane) throws ClassNotFoundException {
        Cliente c = new Cliente();
        DefaultTableModel dtmCliente = (DefaultTableModel) tabela.getModel();
        int i;
        int j;
        c.lerArquivoCliente();
        c.lerArquivoAnimal();
        for (j = 0; j < tabela.getRowCount(); j++) {
            String tel_atual = (String) tabela.getValueAt(j, 3);
            System.out.println(tel_atual);
            int cont = 0;
            for (i = 0; i < c.getIndexa(); i++) {
                String animal = c.getAnimallist(i);
                System.out.println(animal);
                if (animal.equals(tel_atual)) {
                    cont++;
                }
            }

            tabela.setValueAt(cont, j, 4);

        }

    }

    public void PreencherTabelaHistorico(JTable tabela, Component rootPane) {
        try {
            Historico historico = new Historico();
            DefaultTableModel dtmHistorico = (DefaultTableModel) tabela.getModel();
            dtmHistorico.setNumRows(0);
            int i;
            historico.lerArquivoHistorico();
            for (i = 0; i < historico.getIndexh(); i = i + 5) {
                Object[] dados = {historico.getHistoricolist(i), historico.getHistoricolist(i + 1), historico.getHistoricolist(i + 2), historico.getHistoricolist(i + 3), historico.getHistoricolist(i + 4)};
                dtmHistorico.addRow(dados);

            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Tabelas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void PreencherGenero(JTable tabela, Component rootPane) throws ClassNotFoundException {
        Cliente c = new Cliente();
        Relatorios r = new Relatorios();
        DefaultTableModel dtmRelatorio = (DefaultTableModel) tabela.getModel();
        dtmRelatorio.setNumRows(0);
        int i;
        for (i = 0; i < r.getIndexraca(); i++) {
            Object[] dados = {r.getRacalist(i), r.getGenerolist(i)};
            dtmRelatorio.addRow(dados);

        }
    }
    
    @SuppressWarnings("empty-statement")
    public void PreencherRanking(JTable tabela, Component rootPane) throws ClassNotFoundException{
            Cliente c = new Cliente();
            Relatorios r = new Relatorios();
            DefaultTableModel dtmRank = (DefaultTableModel) tabela.getModel();
            dtmRank.setNumRows(0);
            int i,j, max,indexTemp=0;            
            List<String> vencedores = new ArrayList<>();
            List<String> temporarios =  new ArrayList<>();
            for(Object Item: Relatorios.rankinglist){
                temporarios.add((String)Item);
            }
            System.out.println(temporarios);
            for(j=0;j<10;j++){
                max=0;
                for(i=0;i<temporarios.size();i++){
                    if(Integer.parseInt(temporarios.get(i))>max){
                        max= Integer.parseInt(temporarios.get(i));
                        indexTemp = i;
                    }
                }
                vencedores.add(r.getRacalist(indexTemp));
                temporarios.set(indexTemp,"-1");
            }                                                                
            for(i=0;i<10;i++){
                Object[] dados = {vencedores.get(i)};
                dtmRank.addRow(dados);                            
            } 
    }
}
