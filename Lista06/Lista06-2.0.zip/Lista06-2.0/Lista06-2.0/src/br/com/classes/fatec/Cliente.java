/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.classes.fatec;


import java.awt.Component;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author Cliente MMS
 */
public class Cliente implements Serializable {
    
    private String nome;
    private String cpf;
    private String endereco;
    private String telefone;
    private String raca;
    private String genero;
    private String idade;

    
    public Cliente() {
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getIdade() {
        return idade;
    }

    public void setIdade(String idade) {
        this.idade = idade;
    }
    
    //lista
    private final List<String> clientelist = new ArrayList<>();
    public final List<String> animallist = new ArrayList<>();
    private final List<String> contadorlist = new ArrayList<>();
    
    public int getIndex(){             
        return clientelist.size();
    }
    public int getIndexa(){
        return animallist.size();
    }
    public int getIndex_cont(){
        return contadorlist.size();
    }
    //clientelist 
    public String getClientelist(int n){
        return clientelist.get(n);
    }
    public String setClientelist(int n ,String valor){
        return clientelist.set(n, valor);
    }
     public void eliminarClientelist(int n){
        clientelist.remove(n);
    }
    
    //animallist
    public String getAnimallist(int n){
        return animallist.get(n);
    }
    public String setAnimallist(int n ,String valor){
        return animallist.set(n, valor);
    }
    public void eliminarAnimallist(int n){
        animallist.remove(n);
    }
    
    //contadorlist
    public String getContadorlist(int n){
        return contadorlist.get(n);
    }
    public String setContadorlist(int n ,String valor){
        return contadorlist.set(n, valor);
    }
    public void eliminarContadorlist(int n){
        contadorlist.remove(n);
    }
    
    //métodos
    public void salvarListaCliente(String nome, String cpf, String endereco, String telefone){
        clientelist.add(nome);
        clientelist.add(cpf);
        clientelist.add(endereco);
        clientelist.add(telefone);
    }
    
    public void salvarListaAnimal(String raca, String genero, String idade, String telefone){
        animallist.add(raca);
        animallist.add(genero);
        animallist.add(idade);
        animallist.add(telefone);
    }
    
    public void salvarContador(){
        File arq = new File("cliente.ser");
        File arq2 = new File("animal.ser");
        try {
            if(arq.exists() && arq2.exists()){
                FileInputStream fis = new FileInputStream(arq);
                FileInputStream fis2 = new FileInputStream(arq2);
                ObjectInputStream ois = new ObjectInputStream(fis);
                ObjectInputStream ois2 = new ObjectInputStream(fis2);
                ArrayList<Object> lista_cliente = (ArrayList<Object>) ois.readObject();
                ArrayList<Object> lista_animal = (ArrayList<Object>) ois2.readObject();
                int n = lista_cliente.size();
                int n2 = lista_animal.size();
                int i = 0;
                String telefone = null;
                for(Object item: lista_cliente){
                    if(i == 3){
                        telefone = ((String)item);
                        int indic = 0;
                        for (String x : contadorlist) {
                            if(x == telefone){
                                indic = 1;
                                break;
                            } 
                        }
                        if(indic == 0){
                            contadorlist.add(telefone);
                        }
                        
                        i = -1;
                        
                        int cont = 0;
                        for(Object valor: lista_animal){
                            if((String)valor == telefone){
                                cont++;
                            }
                        }
                        
                        int z = 0;
                        int aux = 0;
                        for (String x : contadorlist) {
                            if(x == telefone){
                                aux = z;
                            } 
                            if(Integer.parseInt(x) <= 5 && z-aux == 1){
                                setContadorlist(z, Integer.toString(cont));
                                break;
                            }
                            else{
                                contadorlist.add(Integer.toString(cont));
                            }
                            z++;
                        }
                    }
                    
                    i++;
                    
                }
                ois.close();
                ois2.close();
            }
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    //deletar arquivo existente e criar novo
    public void gravarCliente(Component rootPane){
        File arq = new File("cliente.ser");
        try {
            arq.delete();
            FileOutputStream fos = new FileOutputStream(arq);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(clientelist);
            oos.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
}
    
    public void gravarAnimal(Component rootPane){
        File arq = new File("animal.ser");
        try {
            arq.delete();
            FileOutputStream fos = new FileOutputStream(arq);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(animallist);
            oos.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
}
    
        public void gravarContador(Component rootPane){
        File arq = new File("cont.ser");
        try {
            arq.delete();
            FileOutputStream fos = new FileOutputStream(arq);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(contadorlist);
            oos.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
}
    //ler arquivo serializado e adicionar na lista temporária
    public void lerArquivoCliente() throws ClassNotFoundException{        
        File arq = new File("cliente.ser");
        try {
            if(arq.exists()){
                FileInputStream fis = new FileInputStream(arq);
                ObjectInputStream ois = new ObjectInputStream(fis);
                ArrayList<Object> lista = (ArrayList<Object>) ois.readObject();
                int n = lista.size();
                int i = 0;
                clientelist.clear();
                for(Object item: lista){
                    clientelist.add((String)item);

                    i++;
                }
                ois.close();
            }
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
}
    
        //ler arquivo serializado e adicionar na lista temporária
    public void lerArquivoAnimal() throws ClassNotFoundException{        
        File arq = new File("animal.ser");
        try {
            if(arq.exists()){
                FileInputStream fis = new FileInputStream(arq);
                ObjectInputStream ois = new ObjectInputStream(fis);
                ArrayList<Object> lista = (ArrayList<Object>) ois.readObject();
                int n = lista.size();
                int i = 0;
                animallist.clear();
                for(Object item: lista){
                    animallist.add((String)item);

                    i++;
                }
                ois.close();
            }
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
}
    
            //ler arquivo serializado e adicionar na lista temporária
    public void lerArquivoContador() throws ClassNotFoundException{        
        File arq = new File("cont.ser");
        try {
            if(arq.exists()){
                FileInputStream fis = new FileInputStream(arq);
                ObjectInputStream ois = new ObjectInputStream(fis);
                ArrayList<Object> lista = (ArrayList<Object>) ois.readObject();
                int n = lista.size();
                int i = 0;
                contadorlist.clear();
                for(Object item: lista){
                    contadorlist.add((String)item);

                    i++;
                }
                ois.close();
            }
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
}
    
    public boolean lerLimite(String telefone) throws ClassNotFoundException{        
        File arq = new File("cont.ser");
        boolean pode = true;
        int limite = 0;
        try {
            if(arq.exists()){
                FileInputStream fis = new FileInputStream(arq);
                ObjectInputStream ois = new ObjectInputStream(fis);
                ArrayList<Object> lista = (ArrayList<Object>) ois.readObject();
                int n = lista.size();
                int i = 0;
                int aux = 0;
                if (n != 0){
                    for(Object item: lista){
                        if((String) item == telefone){
                            aux = i;
                        }
                        if(i-aux == 1){
                            limite = (Integer)item;
                            break;
                        }

                        i++;
                }
                }
                
                ois.close();
                if(limite == 5){
                    pode = false;
                }
            }
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return pode;
        
}
    //procura cliente dentro da lista serializada
    public String procuraDono(Component rootPane, String nome){
        File arq = new File("cliente.ser");
        String tel = null;
        try {
            if(arq.exists()){
                FileInputStream fis = new FileInputStream(arq);
                try (ObjectInputStream ois = new ObjectInputStream(fis)) {
                    ArrayList<Object> lista = (ArrayList<Object>) ois.readObject();
                    int n = lista.size();
                    int i = 0;
                    int indice = 0;
                    for(Object item: lista){
                        if(((String) item).equals(nome) ){
                            indice = i;
                        }
                        if(i - indice == 3){
                            tel = ((String) item);

                        }
                        i++;
                    }
            }
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return tel;
    }
    
    public boolean procuraCliente(Component rootPane, String telefone){
        boolean achou = false;
        File arq = new File("cliente.ser");
        try {
            if(arq.exists()){
                FileInputStream fis = new FileInputStream(arq);
                try (ObjectInputStream ois = new ObjectInputStream(fis)) {
                    ArrayList<Object> lista = (ArrayList<Object>) ois.readObject();
                    int n = lista.size();
                    int i;
                    for(Object item: lista){
                        if(((String) item).equals(telefone) ){
                            achou = true;
                            break;
                        }
                    }
            }
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return achou;
    }
   
}
