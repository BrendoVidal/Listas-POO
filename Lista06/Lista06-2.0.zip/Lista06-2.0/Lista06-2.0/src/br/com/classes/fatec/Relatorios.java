/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.classes.fatec;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Cliente MMS
 */
public class Relatorios {

    private String raca;

    public Relatorios() {

    }

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }

    public static List<String> rankinglist = new ArrayList<>();
    public static List<String> racalist = new ArrayList<>();
    public static List<String> generolist = new ArrayList<>();

    public int getIndexranking() {
        return rankinglist.size();
    }

    public int getIndexg() {
        return generolist.size();
    }

    public int getIndexraca() {
        return racalist.size();
    }

    public String getRankinglist(int n) {
        return rankinglist.get(n);
    }

    public String setRankinglist(int n, String valor) {
        return generolist.set(n, valor);
    }

    public String getGenerolist(int n) {
        return generolist.get(n);
    }

    public String setGenerolist(int n, String valor) {
        return generolist.set(n, valor);
    }

    public String getRacalist(int n) {
        return racalist.get(n);
    }

    public String setRacalist(int n, String valor) {
        return racalist.set(n, valor);
    }

    public void salvarListaRanking(String raca) {
        rankinglist.add(raca);
    }

    public void salvarListaGenero(String genero) {
        generolist.add(genero);
    }

    public void salvarListaRaca(String racas) {
        racalist.add(racas);
    }

    public void salvarRacas(List<String> lista, int Index) {
        racalist.clear();
        boolean libera = true;
        for (int i = 0; i < Index; i = i + 4) {
            libera = true;
            for (Object Item : racalist) {
                if(((String)Item).equals(lista.get(i))){
                    libera = false;
                }
            }
            if(libera){
                racalist.add(lista.get(i));
            }
        }
    }

    public void salvarRankings(List<String> lista, List<String> animal) {
        rankinglist.clear();
        generolist.clear();
        for (int i = 0; i < lista.size(); i++) {
            String primeira = lista.get(i);
            int cont = 0;
            int mcount = 0;
            int fcount = 0;
            for (int j = 0; j < animal.size(); j++) {
                if (primeira.equals(animal.get(j))) {
                    cont++;
                    String var = animal.get(j + 1);
                    if (var.toUpperCase().equals("M")) {
                        mcount++;
                    } else if (var.toUpperCase().equals("F")) {
                        fcount++;
                    }
                }

            }

            String contt = Integer.toString(cont);
            rankinglist.add(contt);

            if (mcount > fcount) {
                generolist.add("M");
            } else if (fcount > mcount) {
                generolist.add("F");
            } else {
                generolist.add("Qtd iguais");
            }

        }

    }

}
