/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.classes.fatec;

import java.awt.Component;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Cliente MMS
 */
public class Historico implements Serializable {
    
    private String data;
    private String horario;
    private String cliente;
    private String animal;
    private String petsitter;

    public Historico(){
        
    }
    
    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public String getAnimal() {
        return animal;
    }

    public void setAnimal(String animal) {
        this.animal = animal;
    }

    public String getPetsitter() {
        return petsitter;
    }

    public void setPetsitter(String petsitter) {
        this.petsitter = petsitter;
    }

    private final List<String> historicolist = new ArrayList<>();
    
    public int getIndexh(){             
        return historicolist.size();
    }
    
    public String getHistoricolist(int n){
        return historicolist.get(n);
    }
    public String setHistoricolist(int n ,String valor){
        return historicolist.set(n, valor);
    }
    
    public void salvarListaHistorico(String data, String horario, String cliente, String animal, String petsitter){
        historicolist.add(data);
        historicolist.add(horario);
        historicolist.add(cliente);
        historicolist.add(animal);
        historicolist.add(petsitter);

    }
    
        //deletar arquivo existente e criar novo
    public void gravarHistorico(Component rootPane){
        File arq = new File("historico.ser");
        try {
            arq.delete();
            FileOutputStream fos = new FileOutputStream(arq);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(historicolist);
            oos.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
}
    
     //ler arquivo serializado e adicionar na lista temporária
    public void lerArquivoHistorico() throws ClassNotFoundException{        
        File arq = new File("historico.ser");
        try {
            if(arq.exists()){
                FileInputStream fis = new FileInputStream(arq);
                ObjectInputStream ois = new ObjectInputStream(fis);
                ArrayList<Object> lista = (ArrayList<Object>) ois.readObject();
                int n = lista.size();
                int i = 0;
                historicolist.clear();
                for(Object item: lista){
                    historicolist.add((String)item);

                    i++;
                }
                ois.close();
            }
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
}
    
    
}
