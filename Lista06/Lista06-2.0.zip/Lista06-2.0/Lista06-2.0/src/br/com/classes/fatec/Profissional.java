/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.classes.fatec;



import java.awt.Component;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author Cliente MMS
 */
public class Profissional implements Serializable{
    
    private String nome;
    private String cpf;
    private String endereco;
    private String telefone;
    
     public Profissional() {
    }
    public String getNome() {      
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }
    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
      
    //lista
    private final List<String> profissionallist = new ArrayList<>();
    
    public String getProfissionallist(int n){
        return profissionallist.get(n);
    }
    
    public String setProfissionallist(int n ,String valor){
        return profissionallist.set(n, valor);
    }
    
    
    public int getIndex(){
        return profissionallist.size();
    }
    
    //métodos
    public void salvarLista(String nome, String cpf, String endereco, String telefone){
        profissionallist.add(nome);
        profissionallist.add(cpf);
        profissionallist.add(endereco);
        profissionallist.add(telefone);
    }
    
    //deletar arquivo existente e criar novo
    public void gravarProfissional(Component rootPane){
        File arq = new File("profissional.ser");
        try {
            arq.delete();
            FileOutputStream fos = new FileOutputStream(arq);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(profissionallist);
            oos.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
}
    //ler arquivo serializado e adicionar na lista temporária
    public void lerArquivo() throws ClassNotFoundException{        
        File arq = new File("profissional.ser");
        try {
            if(arq.exists()){
                FileInputStream fis = new FileInputStream(arq);
                ObjectInputStream ois = new ObjectInputStream(fis);
                ArrayList<Object> lista = (ArrayList<Object>) ois.readObject();
                int n = lista.size();
                int i = 0;
                profissionallist.clear();
                for(Object item: lista){
                    profissionallist.add((String)item);

                    i++;
                }
                ois.close();
            }
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
}
    //procura cliente dentro da lista serializada
    public boolean procuraProfissional(Component rootPane, String telefone){
        boolean achou = false;
        File arq = new File("profissional.ser");
        try {
            if(arq.exists()){
                FileInputStream fis = new FileInputStream(arq);
                try (ObjectInputStream ois = new ObjectInputStream(fis)) {
                    ArrayList<Object> lista = (ArrayList<Object>) ois.readObject();
                    int n = lista.size();
                    int i;
                    for(Object item: lista){
                        if(((String) item).equals(telefone) ){
                            achou = true;
                            break;
                        }
                    }
            }
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return achou;
    }
    
    

   
}
